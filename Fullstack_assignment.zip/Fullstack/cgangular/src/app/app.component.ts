import { Component } from '@angular/core';
import {Router, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'cgangular';

  constructor(private router: Router){}

  navigateToLearnJourney(){
    console.log('clicked');
    this.router.navigate(['/learning-journey']);
  }
  onLearningJourneyClick(){
    console.log('clicked');
    this.router.navigate(['/learning-journey']);
  }
}

