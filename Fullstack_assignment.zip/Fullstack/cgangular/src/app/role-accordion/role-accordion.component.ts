import { Component } from '@angular/core';

@Component({
  selector: 'app-role-accordion',
  standalone: true,
  imports: [],
  templateUrl: './role-accordion.component.html',
  styleUrl: './role-accordion.component.css'
})
export class RoleAccordionComponent {

}
